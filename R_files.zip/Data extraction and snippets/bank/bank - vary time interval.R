# Run the code in the script "COHA data extraction.R" then do the following

# Load snippets
load("bank_snippets.RData")

# Set desired time interval
time.interval = 10

# Label time periods
break.points = seq(1810, 2010, time.interval)
num.break.points = length(break.points)
period.labels = paste(break.points[1:(num.break.points-1)], break.points[2:num.break.points], sep = "-")
snippets.info$Period = cut(snippets.info$date, breaks = break.points, labels = period.labels, right = FALSE, include.lowest = TRUE)
#table(snippets$Period)
snippets.info$Time = cut(snippets.info$date, breaks = break.points, labels = FALSE, right = FALSE, include.lowest = TRUE)
snippets$Time = snippets.info$Time
#table(snippets$Time)
num.periods = max(snippets$Time)

# Save snippets
# save(snippets, snippets.info, words.used, num.words, num.snippets, snippet.length, snippet.lengths, num.periods, num.genres, file = "bank_snippets.RData")

# Discard variables not needed
rm(time.interval, break.points, num.break.points, period.labels)
