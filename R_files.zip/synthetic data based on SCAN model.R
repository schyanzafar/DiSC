# We sample a SCAN prior and use it to simulate snippet data with varying size D
# The quantities V, K, T, L, q_SW, q_U are fixed as per "kosmos" data
# G is fixed at 1 because we are using SCAN
# Hyperparameters kappa_psi, a, b are fixed as per SCAN assumptions
# However, for the first time period, we sample from N(0,s^2)
# instead of an improper uniform distribution over all real numbers

options(digits = 4)

library(tidyr)
library(plyr)


#############################################################################
# Sample prior ------------------------------------------------------------ #
#############################################################################

load("kosmos_snippets.RData") #read kosmos data
seed.prior = 200
set.seed(seed.prior)

#Set or re-define parameters
q_sw = 0.5 #approximate stopword probability for kosmos
q_u = 0.1 #approximate hapax probability for kosmos
true.kappa.psi = 1/10
true.kappa.phi = invgamma::rinvgamma(1, shape = 7, rate = 3) #as per Frermann & Lapata
num.genres = 1
num.words = round(num.words/(1-q_u)) #so that after hapax removal we are left with approximately the same num.words as kosmos

#Delete kosmos data
snippets = snippets[c(),]
rm(snippets.info, words.used, snippet.lengths, num.snippets)

#Set prior sd for first time period
#I.e. assume distribution N(0,s^2) and set s with reference to an event considered extreme a priori
phi.1.sd = log(10)/3 / sqrt(2) #regard phi.x-phi.y>log(10) as a 3-sigma event -- we want all senses to be represented in the simulated data
psi.1.sd = log(1000)/3 / sqrt(2) #regard psi.x-psi.y>log(1000) as a 3-sigma event

#Sample phi
true.phi = array(0, dim = c(num.senses, num.genres, num.periods),
                 dimnames = list(Sense = 1:num.senses, Genre = 1:num.genres, Time = 1:num.periods))
for(g in 1:num.genres){
  true.phi[,g,1] = rnorm(num.senses, 0, phi.1.sd)
  for(t in 2:num.periods){
    true.phi[,g,t] = rnorm(num.senses, true.phi[,g,t-1], sqrt(2*true.kappa.phi))
  }#for t
}#for g
true.phi.tilde = aperm(aaply(exp(true.phi), 2, function(x) t(t(x)/colSums(x)), .drop = FALSE), c(2,1,3))

#Sample psi
true.psi = array(0, dim = c(num.words, num.senses, num.periods),
                 dimnames = list(Word = 1:num.words, Sense = 1:num.senses, Time = 1:num.periods))
for(k in 1:num.senses){
  true.psi[,k,1] = rnorm(num.words, 0, psi.1.sd)
  for(t in 2:num.periods){
    true.psi[,k,t] = rnorm(num.words, true.psi[,k,t-1], sqrt(2*true.kappa.psi))
  }#for t
}#for g
true.psi.tilde = aperm(aaply(exp(true.psi), 3, function(x) t(t(x)/colSums(x))), c(2,3,1))

#Remove extra variables
rm(g,k,t,phi.1.sd,psi.1.sd)



#############################################################################
# Sample snippet data ----------------------------------------------------- #
#############################################################################

num.snippets.per.time.period = 500

seed.data = 2000
set.seed(seed.data)

#Set up data frame to hold data
num.snippets = num.snippets.per.time.period * num.periods
snippets = snippets[c(),]; snippets[1:num.snippets,] = NA
snippets$SnippetID = 1:num.snippets
snippets$genre = 1
snippets$Time = rep(1:num.periods, each = num.snippets.per.time.period)

#Set up vector to hold true sense assignments
true.z = numeric(num.snippets)

#Sample number of stopwords in each snippet
num.SWs = rbinom(num.snippets, snippet.length, q_sw)
snippet.lengths = snippet.length - num.SWs

#Sample snippets
for (d in 1:num.snippets) {
  #Sample sense
  true.z[d] = sample(1:num.senses, size = 1, 
                     prob = true.phi.tilde[,snippets$genre[d],snippets$Time[d]])
  #Sample words
  snippets[d, sample(1:snippet.length, snippet.lengths[d])] = 
    sample(1:num.words, size = snippet.lengths[d], replace = TRUE, 
           prob = true.psi.tilde[, true.z[d], snippets$Time[d]])
}#for d


#Identify hapaxes
empirical.word.freqs = table(factor(stack(snippets[,1:snippet.length])$values, 
                                    levels = unique(stack(snippets[,1:snippet.length])$values)))
hapaxes = names(which(empirical.word.freqs == 1))

#Remove hapaxes
words.used = sort(unique(stack(snippets[,1:snippet.length])$values)) #Vector of all unique words used across all snippets
words.used = words.used[-which(words.used %in% c(NA, hapaxes))] #Ignore hapaxes and stopwords (NA)
num.words = length(words.used) #Size of thinned vocabulary
snippet.lengths = apply(snippets[,1:snippet.length], 1, function(i) {sum(i %in% words.used)}) #recalculate snippet lengths
snippets.word.index = apply(snippets[,1:snippet.length], 2, match, table = words.used)
snippets[,1:snippet.length] = snippets.word.index #remove hapaxes and re-name words

#Delete rows of psi for words that have been thinned out
true.psi = true.psi[words.used,,]
dimnames(true.psi) = list(Word = 1:num.words, Sense = 1:num.senses, Time = 1:num.periods)
true.psi.tilde = aperm(aaply(exp(true.psi), 3, function(x) t(t(x)/colSums(x))), c(2,3,1))

#Remove extra variables
rm(snippets.word.index, d, empirical.word.freqs, hapaxes, num.SWs, words.used)


#Same thinned prior and simulated snippets
save(true.phi, true.phi.tilde, true.psi, true.psi.tilde, true.kappa.phi, true.kappa.psi, q_sw, q_u, 
     snippets,true.z,num.snippets,num.genres,num.periods,num.senses,num.words,snippet.length,snippet.lengths,
     file = paste0("snippets.",num.snippets.per.time.period,".per.period.prior.seed.",seed.prior,
                   ".data.seed.",seed.data,".RData"))

#Load simulated snippets
num.snippets.per.time.period = 500
seed.prior = 200 #200 to reproduce the results in the paper
seed.data = 2000 #2000 to reproduce the results in the paper
load(paste0("snippets.",num.snippets.per.time.period,".per.period.prior.seed.",seed.prior,
            ".data.seed.",seed.data,".RData"))

# #Set phi,psi to true values
# phi = true.phi
# psi = true.psi
# phi.tilde = true.phi.tilde
# psi.tilde = true.psi.tilde
# kappa.phi = true.kappa.phi
# kappa.psi = true.kappa.psi



#############################################################################
# Check Brier score ------------------------------------------------------- #
#############################################################################

# Run model using the separate scripts for DiSC or SCAN, then check Brier scores

burn.in = 5000

#Index of non-empty snippets
idx = which(snippet.lengths > 0)

#Posterior normalised sense probabilities
remove.burn.in = TRUE
if(remove.burn.in == FALSE) {
  sense.probs.sim.normalised = sapply(idx, function(d){
    sense.probs.sim[,,d]/rowSums(sense.probs.sim[,,d])}, simplify = "array")
} else {
  sense.probs.sim.normalised = sapply(idx, function(d){
    sense.probs.sim[-(1:burn.in),,d]/rowSums(sense.probs.sim[-(1:burn.in),,d])}, simplify = "array")
}

#Posterior mean sense probabilities
sense.probs.post.mean = apply(sense.probs.sim.normalised, 2:3, mean)

#Brier scores for all possible permutations of sense labels. Use the lowest
sense.label.perm = combinat::permn(1:num.senses)

min(
sapply(1:length(sense.label.perm), function(p){
  z = as.numeric(factor(true.z, levels = sense.label.perm[[p]]))
  measures::multiclass.Brier(t(sense.probs.post.mean), z[idx])})
)



#############################################################################
# Check the level of sense-time interaction in the data ------------------- #
#############################################################################

#Get empirical psi.tilde for the data
snippets.expanded = gather(cbind(snippets, sense = true.z), key = position, value = word, 1:snippet.length)

word.counts = table(factor(snippets.expanded$word, levels = 1:num.words), 
                    factor(snippets.expanded$sense, levels = 1:num.senses), 
                    factor(snippets.expanded$Time, levels = 1:num.periods), 
                    dnn = c("Word", "Sense", "Time"))

emp.psi.tilde = sapply(1:num.periods, function(t) {sapply(1:num.senses, function(k)
  {word.counts[,k,t]/sum(word.counts[,k,t])}, simplify = "aray" )}, simplify = "array" )
dimnames(emp.psi.tilde) = list(Word = 1:num.words, Sense = 1:num.senses, Time = 1:num.periods)


#For each v, fit a linear regression psi.tilde[v,,] ~ t*k and get the p-value of an F-test for the interaction effect
t = rep(1:num.periods, each = num.senses)
k = as.factor(rep(1:num.senses, num.periods))
interaction.p.value = sapply(1:num.words, function(v){
  anova(lm(as.vector(emp.psi.tilde[v,,]) ~ t*k))[3,5]
})

#Check proportion of context words with significant sense-time interaction effect
sig.level = 0.05
mean(interaction.p.value < sig.level, na.rm = TRUE)

