#############################################################################
# Data simulation --------------------------------------------------------- #
#############################################################################

library(tidyr)
library(plyr)
options(digits = 4)

num.senses = 2
num.words = 6
num.periods = 3
num.genres = 1
num.snippets = 99
snippet.length = 10

SW.prob = 0.3
hapax.prob = 0.1

#Sence prevalence constant over time
phi = array(data = c(0.7, 0.3), 
            dim = c(num.senses, num.genres, num.periods),
            dimnames = list(Sense = 1:num.senses, Genre = 1:num.genres, Time = 1:num.periods))
phi.tilde = aperm(aaply(exp(phi), 2, function(x) t(t(x)/colSums(x)), .drop = FALSE), c(2,1,3))
true.phi = phi
true.phi.tilde = phi.tilde


#Words 1-2 most likely under sense 1; 3-4 under sense 2; for all time periods
psi = array(data = c(numeric(2)+2, numeric(4), 
                     numeric(2), numeric(2)+2, numeric(2)),
            dim = c(num.words, num.senses, num.periods),
            dimnames = list(Word = 1:num.words, Sense = 1:num.senses, Time = 1:num.periods))
psi.tilde = aperm(aaply(exp(psi), 3, function(x) t(t(x)/colSums(x))), c(2,3,1))
true.psi = psi
true.psi.tilde = psi.tilde

#Set up data frame to hold data
snippets = matrix(nrow = num.snippets, ncol = snippet.length + 3)
colnames(snippets) = c(paste("V", 1:snippet.length, sep = ""), "Time", "SnippetID", "genre")
snippets = as.data.frame(snippets, stringsAsFactors=FALSE)
snippets$Time = rep(1:num.periods)
snippets$SnippetID = 1:num.snippets
snippets$genre = 1

#Set up vector to hold true sense assignments
true.z = numeric(num.snippets)

#Simulate data
set.seed(100)

for (d in 1:num.snippets) {
  #Sample sense
  true.z[d] = sample(1:num.senses, size = 1, prob = true.phi.tilde[,snippets$genre[d],snippets$Time[d]])
  
  #Sample words
  snippets[d, 1:snippet.length] = sample(x = c("SW", "hapax", 1:num.words), size = snippet.length, replace = TRUE, 
                                         prob = c(SW.prob, hapax.prob, (1 - SW.prob - hapax.prob) * 
                                                    true.psi.tilde[, true.z[d], snippets$Time[d]]))
  
}#for

#Snippet lengths (not counting hapaxes and stopwords)
snippet.lengths = apply(snippets[,1:snippet.length], 1, function(i) {sum(!(i %in% c("SW", "hapax")))}) 

#Drop stopwords and hapaxes
snippets[,1:snippet.length] = apply(snippets[,1:snippet.length], 2, match, table = 1:num.words)


#Check
plot(as.factor(true.z), xlab = "Senses", main = "Distribution over senses in document")

time = 1
genre = 1
plot(as.factor(true.z[snippets$Time==time & snippets$genre==genre]), xlab = "Senses", 
     main = paste("Distribution over senses for time", time, "genre", genre))

time = 2
genre = 1
plot(as.factor(true.z[snippets$Time==time & snippets$genre==genre]), xlab = "Senses", 
     main = paste("Distribution over senses for time", time, "genre", genre))

time = 3
genre = 1
plot(as.factor(true.z[snippets$Time==time & snippets$genre==genre]), xlab = "Senses", 
     main = paste("Distribution over senses for time", time, "genre", genre))

plot(as.factor(gather(snippets[,1:snippet.length], key = position, value = word)$word), 
     xlab = "Words", main = "Distribution over words in document")

sense = 1
plot(as.factor(gather(snippets[true.z == sense, 1:snippet.length], key = position, value = word)$word), 
     xlab = "Words", main = paste("Distribution over words for sense", sense))

sense = 2
plot(as.factor(gather(snippets[true.z == sense, 1:snippet.length], key = position, value = word)$word), 
     xlab = "Words", main = paste("Distribution over words for sense", sense))


#Write data to file
# save(snippets, num.words, num.snippets, snippet.length, snippet.lengths, num.periods, num.genres, num.senses, file = "snippets.RData")
# save(true.z, file = "true.z.RData")
# save(true.phi, true.phi.tilde, true.psi, true.psi.tilde, file = "true.phi.psi.RData")

#Read data
# load("snippets.RData")
# load("true.z.RData")
# load("true.phi.psi.RData")
