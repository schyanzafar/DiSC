
# Results/Figures reported in the paper are from the following runs

# DiSC - kosmos: 10k mcmc sims from seed 1500, with burn-in of 5k
# DiSC - bank: 10k mcmc sims from seed 500, with burn-in of 5k

# GASC - kosmos: b=2 MALA runs, 10k mcmc sims each run, from seed 2500. Use b=2 run with no burn-in
# GASC - bank: b=2 MALA runs, 10k mcmc sims each run, from seed 500. Use b=2 run with no burn-in

# DiSC/GASC - synthetic data ~ 100-200k mcmc sims (saving e.g. every 10th) from seed 500

library(tidyr)
library(plyr)
library(MCMCpack)

options(digits = 4)

burn.in = 5000



#############################################################################
# ESS per unit time ------------------------------------------------------- #
#############################################################################

# b=2 runs with each sampler, 10k mcmc sims each run, from seed 500. Use the run b=2

#phi.tilde
phi.tilde.ess = sapply(1:num.periods, function(t) sapply(1:num.genres, function(g) effectiveSize(as.mcmc(phi.tilde.sim[,,g,t]))))/as.double(Run.Time, units = "hours")
median(phi.tilde.ess)
IQR(phi.tilde.ess)

#psi.tilde
psi.tilde.post.mean = sapply(1:num.periods, function(t) {sapply(1:num.senses, function(k) {apply(psi.tilde.sim[,,k,t], 2, mean)})}, simplify = "array" )
dimnames(psi.tilde.post.mean) = list(Word = 1:num.words, Sense = 1:num.senses, Time = 1:num.periods)

m = 20
psi.tilde.post.mean.marg.over.time = apply(psi.tilde.post.mean, 1:2, sum) / num.periods
top.m.words.marg.over.time = sapply(1:num.senses, function(k) {order(psi.tilde.post.mean.marg.over.time[,k], decreasing = TRUE)[1:m]})
dimnames(top.m.words.marg.over.time) = list(Rank = 1:m, Sense = 1:num.senses)

Words1 = top.m.words.marg.over.time[,1]
Words2 = top.m.words.marg.over.time[,2]

psi.tilde.ess = array(c(
  sapply(1:num.periods, function(t) {
    effectiveSize(as.mcmc(psi.tilde.sim[, Words1, 1, t])) / as.double(Run.Time, units = "hours")
  }),
  sapply(1:num.periods, function(t) {
    effectiveSize(as.mcmc(psi.tilde.sim[, Words2, 2, t])) / as.double(Run.Time, units = "hours")
  })
), dim = c(m, num.periods, 2))

median(psi.tilde.ess)
IQR(psi.tilde.ess)



#############################################################################
# Trace plots ------------------------------------------------------------- #
#############################################################################

# b=2 runs with each sampler, 10k mcmc sims each run, from seed 500. Use the run b=2

Time = 3
Genre = 1
Sense = 2

#MALA+HMC
setwd("/data/gnateater/sczafar-usb/sczafar/DPhil work (external HD)/Results - bank v4 - all - GASC/2 senses - 20k sims - HMC (1 or 5 steps) - run 1 (seed 500)")
load(paste("phi.tilde.sim", filename.suffix, "RData", sep = "."))
load(paste("run.time", filename.suffix, "RData", sep = "."))
phi.tilde.sim.MALA_HMC = phi.tilde.sim[,Sense,Genre,Time]
Run.Time.MALA_HMC = as.double(Run.Time, units = "hours")

#MALA
setwd("/data/gnateater/sczafar-usb/sczafar/DPhil work (external HD)/Results - bank v4 - all - GASC/2 senses - 50k sims - MALA - run 1 (seed 500)")
load(paste("phi.tilde.sim", filename.suffix, "RData", sep = "."))
load(paste("run.time", filename.suffix, "RData", sep = "."))
phi.tilde.sim.MALA = phi.tilde.sim[,Sense,Genre,Time]
Run.Time.MALA = as.double(Run.Time, units = "hours")

#HMC
setwd("/data/gnateater/sczafar-usb/sczafar/DPhil work (external HD)/Results - bank v4 - all - GASC/2 senses - 20k sims - HMC (5 steps) - run 1 (seed 500)")
load(paste("phi.tilde.sim", filename.suffix, "RData", sep = "."))
load(paste("run.time", filename.suffix, "RData", sep = "."))
phi.tilde.sim.HMC = phi.tilde.sim[,Sense,Genre,Time]
Run.Time.HMC = as.double(Run.Time, units = "hours")

#BG
setwd("/data/gnateater/sczafar-usb/sczafar/DPhil work (external HD)/Results - bank v4 - all - GASC/2 senses - 50k sims - BG - run 1 (seed 500)")
load(paste("phi.tilde.sim", filename.suffix, "RData", sep = "."))
load(paste("run.time", filename.suffix, "RData", sep = "."))
phi.tilde.sim.BG = phi.tilde.sim[,Sense,Genre,Time]
Run.Time.BG = as.double(Run.Time, units = "hours")

#PG
setwd("/data/gnateater/sczafar-usb/sczafar/DPhil work (external HD)/Results - bank v4 - all - GASC/2 senses - 30k sims - PG - run 1 (seed 500)")
load(paste("phi.tilde.sim", filename.suffix, "RData", sep = "."))
load(paste("run.time", filename.suffix, "RData", sep = "."))
phi.tilde.sim.PG = phi.tilde.sim[,Sense,Genre,Time]
Run.Time.PG = as.double(Run.Time, units = "hours")

#PG with approx
setwd("/data/gnateater/sczafar-usb/sczafar/DPhil work (external HD)/Results - bank v4 - all - GASC/2 senses - 50k sims - PG with approx - run 1 (seed 500)")
load(paste("phi.tilde.sim", filename.suffix, "RData", sep = "."))
load(paste("run.time", filename.suffix, "RData", sep = "."))
phi.tilde.sim.PGapprox = phi.tilde.sim[,Sense,Genre,Time]
Run.Time.PGapprox = as.double(Run.Time, units = "hours")

#Plot
par(mfcol = c(3,2))
par(mar=c(3,2,2,1), cex.lab = 1, cex.axis = 1, cex.main = 1, mgp = c(1.5,0.5,0))

run.length = 2/6 #in hours
n.MALA_HMC = num.iterations / Run.Time.MALA_HMC * run.length
n.MALA = num.iterations / Run.Time.MALA * run.length
n.HMC = num.iterations / Run.Time.HMC * run.length
n.BG = num.iterations / Run.Time.BG * run.length
n.PG = num.iterations / Run.Time.PG * run.length
n.PGapprox = num.iterations / Run.Time.PGapprox * run.length

plot.range = range(phi.tilde.sim.BG, phi.tilde.sim.PG, phi.tilde.sim.PGapprox, phi.tilde.sim.HMC,
                   phi.tilde.sim.MALA, phi.tilde.sim.MALA_HMC)

plot(phi.tilde.sim.BG[1:n.BG], type = "l", xlab = "Iterations", ylab = "", ylim = plot.range, main = "Aux uniform variable")
plot(phi.tilde.sim.PG[1:n.PG], type = "l", xlab = "Iterations", ylab = "", ylim = plot.range, main = "Aux Polya-Gamma")
plot(phi.tilde.sim.PGapprox[1:n.PGapprox], type = "l", xlab = "Iterations", ylab = "", ylim = plot.range, main = "Aux Polya-Gamma (approx)")
plot(phi.tilde.sim.HMC[1:n.HMC], type = "l", xlab = "Iterations", ylab = "", ylim = plot.range, main = "HMC (5 leapfrog steps)")
plot(phi.tilde.sim.MALA[1:n.MALA], type = "l", xlab = "Iterations", ylab = "", ylim = plot.range, main = "MALA")
plot(phi.tilde.sim.MALA_HMC[1:n.MALA_HMC], type = "l", xlab = "Iterations", ylab = "", ylim = plot.range, main = "MALA+HMC (variable steps)")

# 6in x 6in plot



#############################################################################
# Phi error bars ---------------------------------------------------------- #
#############################################################################

# kosmos error bars - DiSC model
# 10k mcmc sims from seed 1500, with burn-in of 5k

#Index of non-empty snippets
idx = which(snippet.lengths > 0)

conf.level = 0.95

# First get the HPD intervals and posterior means for phi|W
phi.tilde.given.W.conf = array(dim = c(num.senses, 2, num.genres, num.periods),
                               dimnames = list(Sense = 1:num.senses, Limit = c("lower","upper"),
                                               Genre = 1:num.genres, Time = 1:num.periods))
remove.burn.in = TRUE
for (t in 1:num.periods){
  for (g in 1:num.genres){
    if(remove.burn.in == FALSE) {
      phi.tilde.given.W.conf[,,g,t] = HPDinterval( as.mcmc(phi.tilde.sim[,,g,t]), conf.level )
    } else {
      phi.tilde.given.W.conf[,,g,t] = HPDinterval( as.mcmc(phi.tilde.sim[-(1:burn.in),,g,t]), conf.level )
    }
  }#for g
}#for t

#Phi.tilde posterior means
if(remove.burn.in == FALSE) {
  phi.tilde.given.W.mean = sapply(1:num.periods, function(t) {sapply(1:num.genres, function(g) {apply(phi.tilde.sim[,,g,t], 2, mean)}) }, simplify = "array")
} else {
  phi.tilde.given.W.mean = sapply(1:num.periods, function(t) {sapply(1:num.genres, function(g) {apply(phi.tilde.sim[-(1:burn.in),,g,t], 2, mean)}) }, simplify = "array")
}
dimnames(phi.tilde.given.W.mean) = list(Sense = 1:num.senses, Genre = 1:num.genres, Time = 1:num.periods)


# Now load phi.tilde.sim from the phi|z run, and get the HPD intervals and posterior means
phi.tilde.given.z.conf = array(dim = c(num.senses, 2, num.genres, num.periods),
                               dimnames = list(Sense = 1:num.senses, Limit = c("lower","upper"),
                                               Genre = 1:num.genres, Time = 1:num.periods))
remove.burn.in = FALSE #burn-in should be zero
for (t in 1:num.periods){
  for (g in 1:num.genres){
    if(remove.burn.in == FALSE) {
      phi.tilde.given.z.conf[,,g,t] = HPDinterval( as.mcmc(phi.tilde.sim[,,g,t]), conf.level )
    } else {
      phi.tilde.given.z.conf[,,g,t] = HPDinterval( as.mcmc(phi.tilde.sim[-(1:burn.in),,g,t]), conf.level )
    }
  }#for g
}#for t

#Phi.tilde posterior means
if(remove.burn.in == FALSE) {
  phi.tilde.given.z.mean = sapply(1:num.periods, function(t) {sapply(1:num.genres, function(g) {apply(phi.tilde.sim[,,g,t], 2, mean)}) }, simplify = "array")
} else {
  phi.tilde.given.z.mean = sapply(1:num.periods, function(t) {sapply(1:num.genres, function(g) {apply(phi.tilde.sim[-(1:burn.in),,g,t], 2, mean)}) }, simplify = "array")
}
dimnames(phi.tilde.given.z.mean) = list(Sense = 1:num.senses, Genre = 1:num.genres, Time = 1:num.periods)


# expert annotation
z = as.numeric(factor(snippets.info$sense.id[idx]))

# empirical phi
sense.counts = table(factor(z, levels = 1:num.senses), factor(snippets$genre[idx], levels = 1:num.genres), 
                     factor(snippets$Time[idx], levels = 1:num.periods), dnn = c("Sense", "Genre", "Time"))

snippet.counts = table(factor(snippets$genre[idx], levels = 1:num.genres),
                       factor(snippets$Time[idx], levels = 1:num.periods),
                       dnn = c("Genre", "Time"))

phi.tilde = aperm(sapply(1:num.senses, function(k) {sense.counts[k,,] / snippet.counts}, simplify = "array"), c(3,1,2))
dimnames(phi.tilde) = list(Sense = 1:num.senses, Genre = 1:num.genres, Time = 1:num.periods)
phi.tilde[is.nan(phi.tilde)] = 0

#barplots
phi.narrative = phi.tilde[,1,]
phi.non.narrative = phi.tilde[,2,]
dimnames(phi.narrative) = list(Sense = c("Decoration","Order","World"), Time = c((-7):(-1),1:2))
dimnames(phi.non.narrative) = list(Sense = c("Decoration","Order","World"), Time = c((-7):(-1),1:2))

#set up plot window
par(mfrow = c(2,1), oma= c(2,0,0,0), mar=c(2.5,2.5,1.5,0), cex.lab = 0.8, cex.axis = 0.8, cex.main = 0.8, mgp = c(1,0,0))
disp = 0.25 #displace phi|z error bars this much to the left and phi|W error bars this much to the right

#narrative genre
plot.narr = barplot(phi.narrative, beside = TRUE, space = c(0,0.5), col = c("green3","Orange2","Purple1"), 
                    xlab = "Century", yaxt = 'n', main = "Narrative", ylim = c(0,1))
axis(2, mgp = c(1.5,0.5,0)); title(ylab = "Sense prevalence", mgp = c(1.5,0.5,0))

arrows(x0 = as.vector(plot.narr)-disp, y0 = as.vector(phi.tilde.given.z.conf[,1,1,]), 
       y1 = as.vector(phi.tilde.given.z.conf[,2,1,]), code = 3, angle = 90, length = 0.025, lty = 2, lwd = 1)
points(as.vector(plot.narr)-disp, as.vector(phi.tilde.given.z.mean[,1,]), pch = 16, cex = 0.75)

arrows(x0 = as.vector(plot.narr)+disp, y0 = as.vector(phi.tilde.given.W.conf[,1,1,]), 
       y1 = as.vector(phi.tilde.given.W.conf[,2,1,]), code = 3, angle = 90, length = 0.025, lty = 1, lwd = 2)
points(as.vector(plot.narr)+disp, as.vector(phi.tilde.given.W.mean[,1,]), pch = 16, cex = 0.75)

#non-narrative genre
plot.non.narr = barplot(phi.non.narrative, beside = TRUE, space = c(0,0.5), col = c("green3","Orange2","Purple1"), 
                        xlab = "Century", yaxt = 'n', main = "Non-narrative", ylim = c(0,1))
axis(2, mgp = c(1.5,0.5,0)); title(ylab = "Sense prevalence", mgp = c(1.5,0.5,0))

arrows(x0 = as.vector(plot.narr)-disp, y0 = as.vector(phi.tilde.given.z.conf[,1,2,]), 
       y1 = as.vector(phi.tilde.given.z.conf[,2,2,]), code = 3, angle = 90, length = 0.025, lty = 2, lwd = 1)
points(as.vector(plot.narr)-disp, as.vector(phi.tilde.given.z.mean[,2,]), pch = 16, cex = 0.75)

arrows(x0 = as.vector(plot.narr)+disp, y0 = as.vector(phi.tilde.given.W.conf[,1,2,]), 
       y1 = as.vector(phi.tilde.given.W.conf[,2,2,]), code = 3, angle = 90, length = 0.025, lty = 1, lwd = 2)
points(as.vector(plot.narr)+disp, as.vector(phi.tilde.given.W.mean[,2,]), pch = 16, cex = 0.75)

#legend
par(mfrow = c(1,1), oma = c(0,0,0,0), mar = c(0,0,0,0), new = TRUE)
plot(0:1, 0:1, type="n", xlab="", ylab="", axes=FALSE) #overlay emply plot
legend("bottom", legend = c(rownames(phi.narrative), expression(paste("DiSC ",tilde(phi),"|z")), 
                            expression(paste("DiSC ",tilde(phi),"|W"))), 
       fill = c("green3","Orange2","Purple1",NA,NA), col = c("green3","Orange2","Purple1","black","black"), 
       border = c("black","black","black",NA,NA), lty = c(NA,NA,NA,2,1), lwd = c(NA,NA,NA,1,2), bty = "n", horiz = TRUE, 
       cex = 0.9, x.intersp = c(-1.5,-1.5,-1.5,0.5,0.5), text.width = c(0.1,0.08,0.08,0.08,0.08))

#Width = 7, Height = 6



# bank error bars - DiSC/GASC models - run model with 1 genre
# DiSC: 10k mcmc sims from seed 500, with burn-in of 5k
# GASC: b=2 MALA runs, 10k mcmc sims each run, from seed 500. Use b=2 run with no burn-in

#Index of snippets with either the riverbank or the institution bank true sense -- run the following 2 lines for bank only
sense.ids = levels(snippets.info$sense.id)
idx = which(snippets.info$sense.id %in% sense.ids[1:2])
names(idx) = idx #required for consistency with the kosmos data

conf.level = 0.95

# First get the HPD intervals and posterior means for phi|W
phi.tilde.given.W.conf = array(dim = c(num.senses, 2, num.genres, num.periods),
                               dimnames = list(Sense = 1:num.senses, Limit = c("lower","upper"),
                                               Genre = 1:num.genres, Time = 1:num.periods))
remove.burn.in = TRUE
for (t in 1:num.periods){
  for (g in 1:num.genres){
    if(remove.burn.in == FALSE) {
      phi.tilde.given.W.conf[,,g,t] = HPDinterval( as.mcmc(phi.tilde.sim[,,g,t]), conf.level )
    } else {
      phi.tilde.given.W.conf[,,g,t] = HPDinterval( as.mcmc(phi.tilde.sim[-(1:burn.in),,g,t]), conf.level )
    }
  }#for g
}#for t

#Phi.tilde posterior means
if(remove.burn.in == FALSE) {
  phi.tilde.given.W.mean = sapply(1:num.periods, function(t) {sapply(1:num.genres, function(g) {apply(phi.tilde.sim[,,g,t], 2, mean)}) }, simplify = "array")
} else {
  phi.tilde.given.W.mean = sapply(1:num.periods, function(t) {sapply(1:num.genres, function(g) {apply(phi.tilde.sim[-(1:burn.in),,g,t], 2, mean)}) }, simplify = "array")
}
dimnames(phi.tilde.given.W.mean) = list(Sense = 1:num.senses, Genre = 1:num.genres, Time = 1:num.periods)


# save HPD intervals and means as relevant for DiSC or GASC, then calculate it again for the other
phi.tilde.given.W.conf.DiSC = phi.tilde.given.W.conf
phi.tilde.given.W.mean.DiSC = phi.tilde.given.W.mean
rm(phi.tilde.given.W.conf, phi.tilde.given.W.mean)

phi.tilde.given.W.conf.GASC = phi.tilde.given.W.conf
phi.tilde.given.W.mean.GASC = phi.tilde.given.W.mean
rm(phi.tilde.given.W.conf, phi.tilde.given.W.mean)


# Now load phi.tilde.sim from the phi|z run, and get the HPD intervals and posterior means
# Note: no perceptible difference between DiSC and GASC results, so use either
phi.tilde.given.z.conf = array(dim = c(num.senses, 2, num.genres, num.periods),
                               dimnames = list(Sense = 1:num.senses, Limit = c("lower","upper"),
                                               Genre = 1:num.genres, Time = 1:num.periods))
remove.burn.in = FALSE #burn-in should be zero
for (t in 1:num.periods){
  for (g in 1:num.genres){
    if(remove.burn.in == FALSE) {
      phi.tilde.given.z.conf[,,g,t] = HPDinterval( as.mcmc(phi.tilde.sim[,,g,t]), conf.level )
    } else {
      phi.tilde.given.z.conf[,,g,t] = HPDinterval( as.mcmc(phi.tilde.sim[-(1:burn.in),,g,t]), conf.level )
    }
  }#for g
}#for t

#Phi.tilde posterior means
if(remove.burn.in == FALSE) {
  phi.tilde.given.z.mean = sapply(1:num.periods, function(t) {sapply(1:num.genres, function(g) {apply(phi.tilde.sim[,,g,t], 2, mean)}) }, simplify = "array")
} else {
  phi.tilde.given.z.mean = sapply(1:num.periods, function(t) {sapply(1:num.genres, function(g) {apply(phi.tilde.sim[-(1:burn.in),,g,t], 2, mean)}) }, simplify = "array")
}
dimnames(phi.tilde.given.z.mean) = list(Sense = 1:num.senses, Genre = 1:num.genres, Time = 1:num.periods)


# expert annotation
z = as.numeric(factor(snippets.info$sense.id[idx]))

# empirical phi
sense.counts = table(factor(z, levels = 1:num.senses), factor(snippets$genre[idx], levels = 1:num.genres), 
                     factor(snippets$Time[idx], levels = 1:num.periods), dnn = c("Sense", "Genre", "Time"))

snippet.counts = table(factor(snippets$genre[idx], levels = 1:num.genres),
                       factor(snippets$Time[idx], levels = 1:num.periods),
                       dnn = c("Genre", "Time"))

phi.tilde = aperm(sapply(1:num.senses, function(k) {sense.counts[k,,] / snippet.counts}, simplify = "array"), c(3,1,2))
dimnames(phi.tilde) = list(Sense = 1:num.senses, Genre = 1:num.genres, Time = 1:num.periods)
phi.tilde[is.nan(phi.tilde)] = 0

#barplots
phi.all.genres = phi.tilde[,1,]
periods = levels(factor(snippets.info$Period))
dimnames(phi.all.genres) = list(Sense = c("river bank","institution bank"), Time = substr(periods, 1, 4))

#set up plot window
dev.off()
par(oma= c(2,0,0,0), mar=c(2.5,2.5,1.5,0), cex.lab = 0.8, cex.axis = 0.8, cex.main = 0.8, mgp = c(1,0,0))
disp = 0.3 #displace DiSC error bars this much to the left and GASC error bars this much to the right

#bars for all genres
plot.bar = barplot(phi.all.genres, beside = TRUE, space = c(0,0.5), col = c("green3","Orange2"), 
                   xlab = "Time period", yaxt = 'n', main = "All genres", ylim = c(0,1))
axis(2, mgp = c(1.5,0.5,0)); title(ylab = "Sense prevalence", mgp = c(1.5,0.5,0))

#errors for DiSC
arrows(x0 = as.vector(plot.bar)-disp, 
       y0 = as.vector(phi.tilde.given.W.conf.DiSC[,1,1,]), y1 = as.vector(phi.tilde.given.W.conf.DiSC[,2,1,]),
       code = 3, angle = 90, length = 0.015, col = "red", lty = 1, lwd = 2)
points(as.vector(plot.bar)-disp, as.vector(phi.tilde.given.W.mean.DiSC[,1,]), pch = 16, cex = 0.75, col = "red")

#errors for GASC
arrows(x0 = as.vector(plot.bar)+disp, 
       y0 = as.vector(phi.tilde.given.W.conf.GASC[,1,1,]), y1 = as.vector(phi.tilde.given.W.conf.GASC[,2,1,]),
       code = 3, angle = 90, length = 0.015, col = "blue", lty = 1, lwd = 2)
points(as.vector(plot.bar)+disp, as.vector(phi.tilde.given.W.mean.GASC[,1,]), pch = 16, cex = 0.75, col = "blue")

#errors for phi|z
arrows(x0 = as.vector(plot.bar),
       y0 = as.vector(phi.tilde.given.z.conf[,1,1,]), y1 = as.vector(phi.tilde.given.z.conf[,2,1,]),
       code = 3, angle = 90, length = 0.015, col = "black", lty = 2, lwd = 1)
points(as.vector(plot.bar), as.vector(phi.tilde.given.z.mean[,1,]), pch = 16, cex = 0.75, col = "black")

#legend
par(mfrow = c(1,1), oma = c(0,0,0,0), mar = c(0.5,0,0,0), new = TRUE)
plot(0:1, 0:1, type="n", xlab="", ylab="", axes=FALSE) #overlay emply plot
legend("bottom", legend = c(rownames(phi.all.genres), expression(paste("DiSC ",tilde(phi),"|W")), 
                            expression(paste("DiSC/SCAN ",tilde(phi),"|z")), expression(paste("SCAN ",tilde(phi),"|W"))), 
       fill = c("green3","Orange2",NA,NA,NA), col = c("green3","Orange2","red","black","blue"), 
       border = c("black","black",NA,NA,NA),  horiz = TRUE, bty = "n", lty = c(NA,NA,1,2,1), lwd = c(NA,NA,2,1,2),
       cex = 0.8, x.intersp = c(-1.25,-1.25,0.75,0.75,0.75), text.width = c(0.12,0.135,0.1,0.05,0.1))

#Width = 7, Height = 3.5



#############################################################################
# Phi error bars - kosmos with 4 senses - without removing noisy snippets - #
#############################################################################

# kosmos error bars - DiSC model
# 10k mcmc sims from seed 999, with burn-in of 1k

#Set phi column order corresponding to: decoration, order, world, noise
desired.labelling = c(2,1,4,3)

#Index of non-empty snippets
idx = which(snippet.lengths > 0)

conf.level = 0.95

#Normalise phi over four senses (excl noise)
phi.tilde.sim.normalised = sapply(1:num.periods, function(t) {sapply(1:num.genres, function(g) {
  phi.tilde.sim[,desired.labelling[1:3],g,t] / rowSums(phi.tilde.sim[,desired.labelling[1:3],g,t]) }, simplify = "array") }, simplify = "array")
dimnames(phi.tilde.sim.normalised)$Sense = 1:3

# First get the HPD intervals and posterior means for phi|W
phi.tilde.given.W.conf = array(dim = c(3, 2, num.genres, num.periods),
                               dimnames = list(Sense = 1:3, Limit = c("lower","upper"),
                                               Genre = 1:num.genres, Time = 1:num.periods))
remove.burn.in = TRUE
for (t in 1:num.periods){
  for (g in 1:num.genres){
    if(remove.burn.in == FALSE) {
      phi.tilde.given.W.conf[,,g,t] = HPDinterval( as.mcmc(phi.tilde.sim.normalised[,,g,t]), conf.level )
    } else {
      phi.tilde.given.W.conf[,,g,t] = HPDinterval( as.mcmc(phi.tilde.sim.normalised[-(1:burn.in),,g,t]), conf.level )
    }
  }#for g
}#for t

#Phi.tilde posterior means
if(remove.burn.in == FALSE) {
  phi.tilde.given.W.mean = sapply(1:num.periods, function(t) {sapply(1:num.genres, function(g) {apply(phi.tilde.sim.normalised[,,g,t], 2, mean)}) }, simplify = "array")
} else {
  phi.tilde.given.W.mean = sapply(1:num.periods, function(t) {sapply(1:num.genres, function(g) {apply(phi.tilde.sim.normalised[-(1:burn.in),,g,t], 2, mean)}) }, simplify = "array")
}
dimnames(phi.tilde.given.W.mean) = list(Sense = 1:3, Genre = 1:num.genres, Time = 1:num.periods)


# Now load snippets and phi.tilde.sim from the phi|z run, and get the HPD intervals and posterior means
phi.tilde.given.z.conf = array(dim = c(num.senses, 2, num.genres, num.periods),
                               dimnames = list(Sense = 1:num.senses, Limit = c("lower","upper"),
                                               Genre = 1:num.genres, Time = 1:num.periods))
remove.burn.in = FALSE #burn-in should be zero
for (t in 1:num.periods){
  for (g in 1:num.genres){
    if(remove.burn.in == FALSE) {
      phi.tilde.given.z.conf[,,g,t] = HPDinterval( as.mcmc(phi.tilde.sim[,,g,t]), conf.level )
    } else {
      phi.tilde.given.z.conf[,,g,t] = HPDinterval( as.mcmc(phi.tilde.sim[-(1:burn.in),,g,t]), conf.level )
    }
  }#for g
}#for t

#Phi.tilde posterior means
if(remove.burn.in == FALSE) {
  phi.tilde.given.z.mean = sapply(1:num.periods, function(t) {sapply(1:num.genres, function(g) {apply(phi.tilde.sim[,,g,t], 2, mean)}) }, simplify = "array")
} else {
  phi.tilde.given.z.mean = sapply(1:num.periods, function(t) {sapply(1:num.genres, function(g) {apply(phi.tilde.sim[-(1:burn.in),,g,t], 2, mean)}) }, simplify = "array")
}
dimnames(phi.tilde.given.z.mean) = list(Sense = 1:num.senses, Genre = 1:num.genres, Time = 1:num.periods)


# expert annotation
z = as.numeric(factor(snippets.info$sense.id[idx]))

# empirical phi
sense.counts = table(factor(z, levels = 1:num.senses), factor(snippets$genre[idx], levels = 1:num.genres), 
                     factor(snippets$Time[idx], levels = 1:num.periods), dnn = c("Sense", "Genre", "Time"))

snippet.counts = table(factor(snippets$genre[idx], levels = 1:num.genres),
                       factor(snippets$Time[idx], levels = 1:num.periods),
                       dnn = c("Genre", "Time"))

phi.tilde = aperm(sapply(1:num.senses, function(k) {sense.counts[k,,] / snippet.counts}, simplify = "array"), c(3,1,2))
dimnames(phi.tilde) = list(Sense = 1:num.senses, Genre = 1:num.genres, Time = 1:num.periods)
phi.tilde[is.nan(phi.tilde)] = 0

#barplots
phi.narrative = phi.tilde[,1,]
phi.non.narrative = phi.tilde[,2,]
dimnames(phi.narrative) = list(Sense = c("Decoration","Order","World"), Time = c((-7):(-1),1:2))
dimnames(phi.non.narrative) = list(Sense = c("Decoration","Order","World"), Time = c((-7):(-1),1:2))

#set up plot window
par(mfrow = c(2,1), oma= c(2,0,0,0), mar=c(2.5,2.5,1.5,0), cex.lab = 0.8, cex.axis = 0.8, cex.main = 0.8, mgp = c(1,0,0))
disp = 0.25 #displace phi|z error bars this much to the left and phi|W error bars this much to the right

#narrative genre
plot.narr = barplot(phi.narrative, beside = TRUE, space = c(0,0.5), col = c("green3","Orange2","Purple1"), 
                    xlab = "Century", yaxt = 'n', main = "Narrative", ylim = c(0,1))
axis(2, mgp = c(1.5,0.5,0)); title(ylab = "Sense prevalence", mgp = c(1.5,0.5,0))

arrows(x0 = as.vector(plot.narr)-disp, y0 = as.vector(phi.tilde.given.z.conf[,1,1,]), 
       y1 = as.vector(phi.tilde.given.z.conf[,2,1,]), code = 3, angle = 90, length = 0.025, lty = 2, lwd = 1)
points(as.vector(plot.narr)-disp, as.vector(phi.tilde.given.z.mean[,1,]), pch = 16, cex = 0.75)

arrows(x0 = as.vector(plot.narr)+disp, y0 = as.vector(phi.tilde.given.W.conf[,1,1,]), 
       y1 = as.vector(phi.tilde.given.W.conf[,2,1,]), code = 3, angle = 90, length = 0.025, lty = 1, lwd = 2)
points(as.vector(plot.narr)+disp, as.vector(phi.tilde.given.W.mean[,1,]), pch = 16, cex = 0.75)

#non-narrative genre
plot.non.narr = barplot(phi.non.narrative, beside = TRUE, space = c(0,0.5), col = c("green3","Orange2","Purple1"), 
                        xlab = "Century", yaxt = 'n', main = "Non-narrative", ylim = c(0,1))
axis(2, mgp = c(1.5,0.5,0)); title(ylab = "Sense prevalence", mgp = c(1.5,0.5,0))

arrows(x0 = as.vector(plot.narr)-disp, y0 = as.vector(phi.tilde.given.z.conf[,1,2,]), 
       y1 = as.vector(phi.tilde.given.z.conf[,2,2,]), code = 3, angle = 90, length = 0.025, lty = 2, lwd = 1)
points(as.vector(plot.narr)-disp, as.vector(phi.tilde.given.z.mean[,2,]), pch = 16, cex = 0.75)

arrows(x0 = as.vector(plot.narr)+disp, y0 = as.vector(phi.tilde.given.W.conf[,1,2,]), 
       y1 = as.vector(phi.tilde.given.W.conf[,2,2,]), code = 3, angle = 90, length = 0.025, lty = 1, lwd = 2)
points(as.vector(plot.narr)+disp, as.vector(phi.tilde.given.W.mean[,2,]), pch = 16, cex = 0.75)

#legend
par(mfrow = c(1,1), oma = c(0,0,0,0), mar = c(0,0,0,0), new = TRUE)
plot(0:1, 0:1, type="n", xlab="", ylab="", axes=FALSE) #overlay emply plot
legend("bottom", legend = c(rownames(phi.narrative), expression(paste("DiSC ",tilde(phi),"|z")), 
                            expression(paste("DiSC ",tilde(phi),"|W"))), 
       fill = c("green3","Orange2","Purple1",NA,NA), col = c("green3","Orange2","Purple1","black","black"), 
       border = c("black","black","black",NA,NA), lty = c(NA,NA,NA,2,1), lwd = c(NA,NA,NA,1,2), bty = "n", horiz = TRUE, 
       cex = 0.9, x.intersp = c(-1.5,-1.5,-1.5,0.5,0.5), text.width = c(0.1,0.08,0.08,0.08,0.08))

#Width = 7, Height = 6



#############################################################################
# Psi error bars ---------------------------------------------------------- #
#############################################################################

# bank error bars for context word "commercial" - DiSC/GASC models - run model with 1 genre
# DiSC: 10k mcmc sims from seed 500, with burn-in of 5k
# GASC: b=2 MALA runs, 10k mcmc sims each run, from seed 500. Use b=2 run with no burn-in

#Index of snippets with either the riverbank or the institution bank true sense -- run the following 2 lines for bank only
sense.ids = levels(snippets.info$sense.id)
idx = which(snippets.info$sense.id %in% sense.ids[1:2])
names(idx) = idx #required for consistency with the kosmos data

conf.level = 0.95
# commercial - word 162
v = 162

# Get the HPD intervals and posterior means for psi_v|W for a single word v
psi.tilde.given.W.conf = array(dim = c(2, num.senses, num.periods),
                               dimnames = list(Limit = c("lower","upper"), Sense = 1:num.senses, Time = 1:num.periods))
remove.burn.in = TRUE
for (t in 1:num.periods){
  for (g in 1:num.genres){
    if(remove.burn.in == FALSE) {
      psi.tilde.given.W.conf[,,t] = t(HPDinterval( as.mcmc(psi.tilde.sim[,v,,t]), conf.level ))
    } else {
      psi.tilde.given.W.conf[,,t] = t(HPDinterval( as.mcmc(psi.tilde.sim[-(1:burn.in),v,,t]), conf.level ))
    }
  }#for g
}#for t

#Psi.tilde posterior means
if(remove.burn.in == FALSE) {
  psi.tilde.given.W.mean = sapply(1:num.periods, function(t) {sapply(1:num.senses, function(k) {mean(psi.tilde.sim[,v,k,t])}) }, simplify = "array")
} else {
  psi.tilde.given.W.mean = sapply(1:num.periods, function(t) {sapply(1:num.senses, function(k) {mean(psi.tilde.sim[-(1:burn.in),v,k,t])}) }, simplify = "array")
}
dimnames(psi.tilde.given.W.mean) = list(Sense = 1:num.senses, Time = 1:num.periods)

# save HPD intervals and means as relevant for DiSC or GASC, then calculate it again for the other
psi.tilde.given.W.conf.DiSC = psi.tilde.given.W.conf
psi.tilde.given.W.mean.DiSC = psi.tilde.given.W.mean
rm(psi.tilde.given.W.conf, psi.tilde.given.W.mean)

psi.tilde.given.W.conf.GASC = psi.tilde.given.W.conf
psi.tilde.given.W.mean.GASC = psi.tilde.given.W.mean
rm(psi.tilde.given.W.conf, psi.tilde.given.W.mean)

#plots
psi.tilde.v = psi.tilde.given.W.mean.DiSC*0
periods = levels(factor(snippets.info$Period))
dimnames(psi.tilde.v) = list(Sense = c("river-bank","institution bank"), Time = substr(periods, 1, 4))

#set up plot window
#dev.off()
par(oma= c(2,0,0,0), mar=c(2.5,2.5,1.5,0), cex.lab = 0.8, cex.axis = 0.8, cex.main = 0.8, mgp = c(1,0,0))
disp = 0.25 #displace DiSC error bars this much to the left and GASC error bars this much to the right

plot.psi = barplot(psi.tilde.v, beside = TRUE, space = c(0,0.5), col = c("green3","Orange2"), 
                   main = "Context word 'commercial'", xlab = "Time period", yaxt = 'n', 
                   ylim = c(0,max(psi.tilde.given.W.conf.DiSC, psi.tilde.given.W.conf.GASC)))
axis(2, mgp = c(1.5,0.5,0)); title(ylab = "Context probability", mgp = c(1.25,0.5,0))

arrows(x0 = as.vector(plot.psi)-disp, y0 = as.vector(psi.tilde.given.W.conf.DiSC[1,,]), 
       y1 = as.vector(psi.tilde.given.W.conf.DiSC[2,,]), code = 3, angle = 90, length = 0.025, 
       col = c("red","green3"), lty = 3, lwd = 2)
points(as.vector(plot.psi)-disp, as.vector(psi.tilde.given.W.mean.DiSC), pch = 16, cex = 0.9,
       col = c("red","green3"))

arrows(x0 = as.vector(plot.psi)+disp, y0 = as.vector(psi.tilde.given.W.conf.GASC[1,,]), 
       y1 = as.vector(psi.tilde.given.W.conf.GASC[2,,]), code = 3, angle = 90, length = 0.025, 
       col = c("blue","Orange2"), lty = 4, lwd = 2)
points(as.vector(plot.psi)+disp, as.vector(psi.tilde.given.W.mean.GASC), pch = 16, cex = 0.9,
       col = c("blue","Orange2"))

#legend
par(mfrow = c(1,1), oma = c(0,0,0,0), mar = c(0,0,0,0), new = TRUE)
plot(0:1, 0:1, type="n", xlab="", ylab="", axes=FALSE) #overlay emply plot
# legend("bottom", legend = c(expression(paste("river bank  DiSC  ",tilde(psi)["v"]^"k,t"," | W")), 
#                             expression(paste("institution bank  DiSC  ",tilde(psi)["v"]^"k,t"," | W")),
#                             expression(paste("river bank  SCAN  ",tilde(psi)["v"]^"k,t"," | W")),
#                             expression(paste("institution bank  SCAN  ",tilde(psi)["v"]^"k,t"," | W"))), 
#        col = c("red","green3","blue","Orange2"), lty = c(3,3,4,4), lwd = c(2,2,2,2), 
#        bty = "n", ncol = 2, cex = 0.8, y.intersp = 2, 
#        x.intersp = c(0.5,0.5,0.5,0.5), text.width = c(0.25,0.25,0.25,0.25))
legend("bottom", legend = c(expression(paste("DiSC river bank")), 
                            expression(paste("DiSC institution bank")),
                            expression(paste("SCAN river bank")),
                            expression(paste("SCAN institution bank"))), 
       col = c("red","green3","blue","Orange2"), lty = c(3,3,4,4), lwd = c(2,2,2,2), 
       bty = "n", ncol = 2, cex = 0.8, y.intersp = 2, 
       x.intersp = c(0.5,0.5,0.5,0.5), text.width = c(0.25,0.25,0.25,0.25))

#Width = 7, Height = 4



#############################################################################
# Psi error bars for synthetic data --------------------------------------- #
#############################################################################

conf.level = 0.95
v = 1

# Get the HPD intervals and posterior means for psi_v|W for a single word v
psi.tilde.given.W.conf = array(dim = c(2, num.senses, num.periods),
                               dimnames = list(Limit = c("lower","upper"), Sense = 1:num.senses, Time = 1:num.periods))
remove.burn.in = TRUE
for (t in 1:num.periods){
  for (g in 1:num.genres){
    if(remove.burn.in == FALSE) {
      psi.tilde.given.W.conf[,,t] = t(HPDinterval( as.mcmc(psi.tilde.sim[,v,,t]), conf.level ))
    } else {
      psi.tilde.given.W.conf[,,t] = t(HPDinterval( as.mcmc(psi.tilde.sim[-(1:burn.in),v,,t]), conf.level ))
    }
  }#for g
}#for t

#Psi.tilde posterior means
if(remove.burn.in == FALSE) {
  psi.tilde.given.W.mean = sapply(1:num.periods, function(t) {sapply(1:num.senses, function(k) {mean(psi.tilde.sim[,v,k,t])}) }, simplify = "array")
} else {
  psi.tilde.given.W.mean = sapply(1:num.periods, function(t) {sapply(1:num.senses, function(k) {mean(psi.tilde.sim[-(1:burn.in),v,k,t])}) }, simplify = "array")
}
dimnames(psi.tilde.given.W.mean) = list(Sense = 1:num.senses, Time = 1:num.periods)

# save HPD intervals and means as relevant for DiSC or GASC, then calculate it again for the other
psi.tilde.given.W.conf.DiSC = psi.tilde.given.W.conf
psi.tilde.given.W.mean.DiSC = psi.tilde.given.W.mean
rm(psi.tilde.given.W.conf, psi.tilde.given.W.mean)

psi.tilde.given.W.conf.GASC = psi.tilde.given.W.conf
psi.tilde.given.W.mean.GASC = psi.tilde.given.W.mean
rm(psi.tilde.given.W.conf, psi.tilde.given.W.mean)

#barplots
true.psi.tilde.v = true.psi.tilde[v,,]

#set up plot window
par(oma= c(2,0,0,0), mar=c(2.5,2.5,1.5,0), cex.lab = 0.8, cex.axis = 0.8, cex.main = 0.8, mgp = c(1,0,0))
disp = 0.25 #displace DiSC error bars this much to the left and GASC error bars this much to the right

#plots
plot.psi = barplot(true.psi.tilde.v, beside = TRUE, space = c(0,0.5), col = c("green3","Orange2","Purple1"),
                   xlab = "Time period", yaxt = 'n', main = "Sense-Time interaction example 1",
                   ylim = c(0,max(psi.tilde.given.W.conf.DiSC, psi.tilde.given.W.conf.GASC)))
axis(2, mgp = c(1.5,0.5,0)); title(ylab = "Context probability", mgp = c(1.5,0.5,0))

arrows(x0 = as.vector(plot.psi)-disp, y0 = as.vector(psi.tilde.given.W.conf.DiSC[1,,]),
       y1 = as.vector(psi.tilde.given.W.conf.DiSC[2,,]), code = 3, angle = 90, length = 0.025, lty = 3, lwd = 2, col = "red")
points(as.vector(plot.psi)-disp, as.vector(psi.tilde.given.W.mean.DiSC), pch = 16, cex = 0.9, col = "red")

arrows(x0 = as.vector(plot.psi)+disp, y0 = as.vector(psi.tilde.given.W.conf.GASC[1,,]),
       y1 = as.vector(psi.tilde.given.W.conf.GASC[2,,]), code = 3, angle = 90, length = 0.025, lty = 4, lwd = 2, col = "blue")
points(as.vector(plot.psi)+disp, as.vector(psi.tilde.given.W.mean.GASC), pch = 16, cex = 0.9, col = "blue")

#legend
par(mfrow = c(1,1), oma = c(0,0,0,0), mar = c(0.5,0,0,0), new = TRUE)
plot(0:1, 0:1, type="n", xlab="", ylab="", axes=FALSE) #overlay emply plot
legend("bottom", legend = c(expression(paste("true ",tilde(psi)["v"]^"1,t",)), 
                            expression(paste("true ",tilde(psi)["v"]^"2,t",)), 
                            expression(paste("true ",tilde(psi)["v"]^"3,t",)), 
                            expression(paste("DiSC ",tilde(psi)["v"]^"k,t","|W")),
                            expression(paste("SCAN ",tilde(psi)["v"]^"k,t","|W"))),
       fill = c("green3","Orange2","Purple1",NA,NA), col = c("green3","Orange2","Purple1","red","blue"),
       border = c("black","black","black",NA,NA), lty = c(NA,NA,NA,3,4), lwd = c(NA,NA,NA,2,2), bty = "n", horiz = TRUE,
       cex = 0.9, x.intersp = c(-1.5,-1.5,-1.5,0.5,0.5), text.width = c(0.1,0.1,0.1,0.05,0.09))

#Width = 7, Height = 3.5



#############################################################################
# Top words --------------------------------------------------------------- #
#############################################################################

# Top words for kosmos - DiSC model
# 10k mcmc sims from seed 1500, with burn-in of 5k

m = 10 

remove.burn.in = TRUE
if(remove.burn.in == FALSE) {
  psi.tilde.post.mean = sapply(1:num.periods, function(t) {sapply(1:num.senses, function(k) {apply(psi.tilde.sim[,,k,t], 2, mean)})}, simplify = "array" )
} else {
  psi.tilde.post.mean = sapply(1:num.periods, function(t) {sapply(1:num.senses, function(k) {apply(psi.tilde.sim[-(1:burn.in),,k,t], 2, mean)})}, simplify = "array" )
}
dimnames(psi.tilde.post.mean) = list(Word = 1:num.words, Sense = 1:num.senses, Time = 1:num.periods)

lemmas.unique = read.csv("lemmas.unique.csv", header = TRUE, colClasses = "character")

psi.tilde.post.mean.marg.over.time = apply(psi.tilde.post.mean, 1:2, sum) / num.periods
top.m.words.marg.over.time = sapply(1:num.senses, function(k) {order(psi.tilde.post.mean.marg.over.time[,k], decreasing = TRUE)[1:m]})
dimnames(top.m.words.marg.over.time) = list(Rank = 1:m, Sense = 1:num.senses)

top.m.marg.over.time.LemmaIDs = aaply(top.m.words.marg.over.time, 1:2, function(x) {words.used[x]})
top.m.marg.over.time.original = aaply(top.m.marg.over.time.LemmaIDs, 1:2, function(x) {lemmas.unique[match(x, lemmas.unique[,1]),2]})
noquote(t(top.m.marg.over.time.original))

# Top words for kosmos - GASC model
# b=2 runs, 10k mcmc sims each run, from seed 2500. Use b=2 run with no burn-in
# same calcs as above for DiSC

# DiSC - τάξις probabilities - lemmaID 102381 - word 434
psi.tilde.post.mean.marg.over.time[434,] / sum(psi.tilde.post.mean.marg.over.time[434,])
0.43 + 0.42 + 0.15


# Top words for kosmos - expert annotation
idx = which(snippet.lengths > 0) ##Index of non-empty snippets
z = as.numeric(factor(snippets.info$sense.id))
snippets.expanded = gather(cbind(snippets[idx,], sense = z[idx]), key = position, value = word, 1:snippet.length)
word.counts = table(factor(snippets.expanded$word, levels = 1:num.words),
                    factor(snippets.expanded$sense, levels = 1:num.senses),
                    dnn = c("Word", "Sense"))

psi.tilde.marg.over.time = sapply(1:num.senses, function(k) {(word.counts[,k])/(sum(word.counts[,k]))}, simplify = "aray")
dimnames(psi.tilde.marg.over.time) = list(Word = 1:num.words, Sense = 1:num.senses)

#Top m words with highest posterior mean for each sense across all time periods
m = 10 
top.m.words.marg.over.time = sapply(1:num.senses, function(k) {order(psi.tilde.marg.over.time[,k], decreasing = TRUE)[1:m]})
dimnames(top.m.words.marg.over.time) = list(Rank = 1:m, Sense = 1:num.senses)

top.m.marg.over.time.LemmaIDs = aaply(top.m.words.marg.over.time, 1:2, function(x) {words.used[x]})
top.m.marg.over.time.original = aaply(top.m.marg.over.time.LemmaIDs, 1:2, function(x) {lemmas.unique[match(x, lemmas.unique[,1]),2]})
noquote(t(top.m.marg.over.time.original))

options(digits = 3)
# θεός - lemmaID 48291 - word 122
psi.tilde.marg.over.time[122,] / sum(psi.tilde.marg.over.time[122,])
# ἀνήρ - lemmaID 8665 - word 71
psi.tilde.marg.over.time[71,] / sum(psi.tilde.marg.over.time[71,])
# πόλις - lemmaID 84494 - word 141
psi.tilde.marg.over.time[141,] / sum(psi.tilde.marg.over.time[141,])



#############################################################################
# Brier scores ------------------------------------------------------------ #
#############################################################################

#Index of non-empty snippets
idx = which(snippet.lengths > 0)

#Index of snippets with either the riverbank or the institution bank true sense -- run the following 2 lines for bank only
sense.ids = levels(snippets.info$sense.id)
idx = which(snippets.info$sense.id %in% sense.ids[1:2])
names(idx) = idx #required for consistency with the kosmos data

#Posterior normalised sense probabilities
remove.burn.in = TRUE
if(remove.burn.in == FALSE) {
  sense.probs.sim.normalised = sapply(idx, function(d){
    sense.probs.sim[,,d]/rowSums(sense.probs.sim[,,d])}, simplify = "array")
} else {
  sense.probs.sim.normalised = sapply(idx, function(d){
    sense.probs.sim[-(1:burn.in),,d]/rowSums(sense.probs.sim[-(1:burn.in),,d])}, simplify = "array")
}

#Posterior mean sense probabilities
sense.probs.post.mean = apply(sense.probs.sim.normalised, 2:3, mean)

#Brier score
measures::multiclass.Brier(t(sense.probs.post.mean), as.numeric(factor(snippets.info$sense.id[idx])))

# Brier score - DiSC - kosmos: 10k mcmc sims from seed 1500, with burn-in of 5k
# Brier score - GASC - kosmos: b=2 MALA runs, 10k mcmc sims each run, from seed 2500. Use b=2 run with no burn-in
# Brier score - DiSC - bank: 10k mcmc sims from seed 500, with burn-in of 5k
# Brier score - GASC - bank: b=2 MALA runs, 10k mcmc sims each run, from seed 500. Use b=2 run with no burn-in



#############################################################################
# Brier scores - kosmos with 4 senses - without removing noisy snippets --- #
#############################################################################

#Set phi column order corresponding to: decoration, order, world, noise
desired.labelling = c(2,1,4,3)

#Normalise posterior sense probabilities over four senses (incl noise)
remove.burn.in = TRUE
if(remove.burn.in == FALSE) {
  sense.probs.sim.normalised = sapply(1:num.snippets, function(d){
    sense.probs.sim[,,d]/rowSums(sense.probs.sim[,,d])}, simplify = "array")
} else {
  sense.probs.sim.normalised = sapply(1:num.snippets, function(d){
    sense.probs.sim[-(1:burn.in),,d]/rowSums(sense.probs.sim[-(1:burn.in),,d])}, simplify = "array")
}

#Posterior mean sense probabilities
sense.probs.post.mean = apply(sense.probs.sim.normalised, 2:3, mean)

#Normalise posterior mean sense probabilities over three senses (excl noise)
sense.probs.post.mean = t(t(sense.probs.post.mean[desired.labelling[1:3],]) /
                            colSums(sense.probs.post.mean[desired.labelling[1:3],]))
dimnames(sense.probs.post.mean)$Sense = 1:3

#Check: columns sum to 1
all(abs(colSums(sense.probs.post.mean)-1) < 10^-6)

# #Index of non-empty snippets, excluding snippets with "w" sense
idx = which((snippet.lengths > 0) & (snippets.info$sense.id != "w"))

#Index of non-empty snippets for type "collocates" only
idx = which((snippet.lengths > 0) & (snippets.info$disambiguation==1))

#Brier score
measures::multiclass.Brier(t(sense.probs.post.mean[,idx]), as.numeric(factor(snippets.info$sense.id[idx])))

# Brier score - DiSC - kosmos: 10k mcmc sims from seed 999, with burn-in of 1k



#############################################################################
# Confusion matrix -------------------------------------------------------- #
#############################################################################

# DiSC - bank: 10k mcmc sims from seed 500, with burn-in of 5k
# GASC - bank: b=2 MALA runs, 10k mcmc sims each run, from seed 500. Use b=2 run with no burn-in

#Assign sense to each snippet based on the highest posterior probability
z.post.mode = apply(sense.probs.post.mean, 2, which.max)

#Confusion matrix
caret::confusionMatrix(factor(z.post.mode), factor(snippets.info$sense.id[idx], labels = 1:num.senses))


