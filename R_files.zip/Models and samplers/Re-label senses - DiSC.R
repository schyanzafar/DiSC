#############################################################################
# Re-label senses --------------------------------------------------------- #
#############################################################################

#Desired sense labelling 
#E.g. we want sense 2 to be re-labelled 1, 3 to be re-labelled 2, and 1 to be re-relabelled 3.
#Then we would set desired.labelling = c(2,3,1)
desired.labelling = c(2,3,1)

# z[] = factor(z, levels = desired.labelling)

phi.tilde.sim[] = phi.tilde.sim[,desired.labelling,,]
psi.tilde.sim[] = psi.tilde.sim[,,desired.labelling,]
chi.sim[] = chi.sim[,,desired.labelling]
sense.probs.sim[] = sense.probs.sim[,desired.labelling,]

