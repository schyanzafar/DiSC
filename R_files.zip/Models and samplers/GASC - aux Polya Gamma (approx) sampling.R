#############################################################################
# Required libraries ------------------------------------------------------ #
#############################################################################

library(tidyr)
library(plyr)
library(MCMCpack)
library(invgamma)
library(pgdraw)

options(digits = 4)



#############################################################################
# Parameter updates ------------------------------------------------------- #
#############################################################################

#Write a function to update the rate hyperparameter for kappa.phi using current phi
update.kappa.phi.rate.single.genre = function(phi.g) {
  
  differences = t(diff(t(phi.g)))
  
  sum(differences^2)
  
}#update.kappa.phi.rate.single.genre

update.kappa.phi.rate = function(phi) {
  
  kappa.phi.rate.prior + 0.25 * sum(apply(phi, 2, update.kappa.phi.rate.single.genre))
  
}#update.kappa.phi.rate


#Write a function to update kappa.phi given hyperparameters
update.kappa.phi = function(kappa.phi.shape, kappa.phi.rate) {
  
  invgamma::rinvgamma(1, shape = kappa.phi.shape, rate = kappa.phi.rate)
  
}#update.kappa.phi


#Write a function that takes as input a single snippet, phi and psi, 
#and returns a vector of (unnormalised) sense probabilities for that snippet
get.sense.prob = function(snippet, phi.tilde, psi.tilde) {
  apply(psi.tilde[snippet,], 2, prod, na.rm = TRUE) * phi.tilde
}#get.sense.prob


#Write a function to update phi (for a single time period) using the Polya Gamma strategy
update.phi.t.polya.gamma = function(phi.t, phi.prior.mean, phi.prior.var, sense.counts, sense.count.total, 
                                    update.direction = 1:num.senses, num.updates = 1) {
  
  #Store values to same computation time
  exp.phi.t = exp(phi.t)
  sum.exp.phi.t = sum(exp.phi.t)
  
  #num.updates specifies how many times to iteratively update phi
  for(iter in 1:num.updates) {
    
    #Cycle through each topic
    for (k in update.direction) {
      
      #Sample Polya Gamma variable given current value of phi
      C = log(sum.exp.phi.t - exp.phi.t[k])
      eta = phi.t[k] - C
      
      #Exact PG sample
      # pg = pgdraw(sense.count.total, eta)
      
      #Approximate PG sample:
      aux = pgdraw(1, eta)
      pg = sqrt(sense.count.total) * (aux - 0.5/eta*tanh(eta/2)) + 0.5*sense.count.total/eta*tanh(eta/2)
      
      #Calculate variance and mean of posterior (Gaussian) distribution
      V = 1 / ( 1/phi.prior.var + pg )
      m = V * ( phi.prior.mean[k]/phi.prior.var + (sense.counts[k] - sense.count.total/2) + pg*C )
      
      #Sample from posterior
      phi.t[k] = rnorm(1, m, sqrt(V))
      
      #Update stored parameters
      exp.phi.k.t = exp(phi.t[k])
      sum.exp.phi.t = sum.exp.phi.t - exp.phi.t[k] + exp.phi.k.t
      exp.phi.t[k] = exp.phi.k.t
      
    }#for
    
    #Reverse update direction for next iteration
    update.direction = rev(update.direction)
    
  }#for
  
  # phi.t = phi.t - phi.t[num.senses]
  phi.tilde.t = exp.phi.t / sum.exp.phi.t
  
  out = list(phi.t = phi.t, phi.tilde.t = phi.tilde.t)
  
  return(out)
  
}#update.phi.t.polya.gamma


#Write a function to update phi using the Polya Gamma strategy
update.phi.polya.gamma = function(phi, sense.counts, snippet.counts, update.direction = 1:num.senses, num.updates = 1) {
  
  #Cycle through all genres
  for (g in 1:num.genres) {
    
    #Cycle through all time periods
    for (t in time.direction) {
      
      #Compute prior means and variance
      if (t == 1) {
        
        phi.prior.mean = phi[,g,t+1]
        phi.prior.var = 2*kappa.phi
        
      } else if (t == num.periods) {
        
        phi.prior.mean = phi[,g,t-1]
        phi.prior.var = 2*kappa.phi
        
      } else {
        
        phi.prior.mean = (phi[,g,t-1] + phi[,g,t+1]) / 2
        phi.prior.var = kappa.phi
        
      }#else
      
      #If no data then sample from prior
      if (snippet.counts[g,t] ==  0) {
        
        phi[,g,t] = rnorm(num.senses, phi.prior.mean, sqrt(phi.prior.var))
        # phi[,g,t] = phi[,g,t] - phi[num.senses,g,t]
        
        exp.phi.g.t = exp(phi[,g,t])
        phi.tilde[,g,t] = exp.phi.g.t / sum(exp.phi.g.t)
        
        #else sample using Polya Gamma
      } else { 
        
        phi.PG.output = update.phi.t.polya.gamma(phi[,g,t], phi.prior.mean, phi.prior.var, 
                                                 sense.counts[,g,t], snippet.counts[g,t], 
                                                 update.direction, num.updates)
        
        phi[,g,t] = phi.PG.output$phi.t
        phi.tilde[,g,t] = phi.PG.output$phi.tilde.t
        
      }#else
      
    }#for t
    
  }#for g
  
  out = list(phi = phi, phi.tilde = phi.tilde)
  
  return(out)
  
}#update.phi.polya.gamma


#Write a function to update psi (for a single sense column and single time period) using the Polya Gamma strategy
update.psi.k.t.polya.gamma = function(psi.k.t, psi.prior.mean, psi.prior.var, word.counts, word.count.total, 
                                      update.direction = 1:num.words, num.updates = 1) {

  #Store values to same computation time
  exp.psi.k.t = exp(psi.k.t)
  sum.exp.psi.k.t = sum(exp.psi.k.t)

  #num.updates specifies how many times to iteratively update psi
  for(iter in 1:num.updates) {
    
    #Cycle through each word
    for (w in update.direction) {
      
      #Sample Polya Gamma variable given current value of psi
      C = log(sum.exp.psi.k.t - exp.psi.k.t[w])
      eta = psi.k.t[w] - C
      
      #Exact PG sample:
      # pg = pgdraw(word.count.total, eta)
      
      #Approximate PG sample:
      aux = pgdraw(1, eta)
      pg = sqrt(word.count.total) * (aux - 0.5/eta*tanh(eta/2)) + 0.5*word.count.total/eta*tanh(eta/2)
      
      #Calculate variance and mean of posterior (Gaussian) distribution
      V = 1 / ( 1/psi.prior.var + pg )
      m = V * ( psi.prior.mean[w]/psi.prior.var + (word.counts[w] - word.count.total/2) + pg*C )
      
      #Sample from posterior
      psi.k.t[w] = rnorm(1, m, sqrt(V))
      
      #Update stored parameters
      exp.psi.w.k.t = exp(psi.k.t[w])
      sum.exp.psi.k.t = sum.exp.psi.k.t - exp.psi.k.t[w] + exp.psi.w.k.t
      exp.psi.k.t[w] = exp.psi.w.k.t
      
    }#for
    
    #Reverse update direction for next iteration
    update.direction = rev(update.direction)
    
  }#for
  
  # psi.k.t = psi.k.t - psi.k.t[num.words]
  psi.tilde.k.t = exp.psi.k.t / sum.exp.psi.k.t
  
  out = list(psi.k.t = psi.k.t, psi.tilde.k.t = psi.tilde.k.t)
  
  return(out)
  
}#update.psi.k.t.polya.gamma


#Write a function to update psi using the Polya Gamma strategy
update.psi.polya.gamma = function(psi, word.counts, word.count.totals, update.direction = 1:num.words, num.updates = 1) {
  
  #Cycle through all senses
  for (k in sense.direction) {
    
    #Cycle through all time periods
    for (t in time.direction) {
      
      #Compute prior means and variance
      if (t == 1) {
        
        psi.prior.mean = psi[,k,t+1]
        psi.prior.var = 2*kappa.psi
        
      } else if (t == num.periods) {
        
        psi.prior.mean = psi[,k,t-1]
        psi.prior.var = 2*kappa.psi
        
      } else {
        
        psi.prior.mean = (psi[,k,t-1] + psi[,k,t+1]) / 2
        psi.prior.var = kappa.psi
          
      }#else
      
      #If no data then sample from prior
      if (word.count.totals[k,t] ==  0) {
        
        psi[,k,t] = rnorm(num.words, psi.prior.mean, sqrt(psi.prior.var))
        # psi[,k,t] = psi[,k,t] - psi[num.words,k,t]
        
        exp.psi.k.t = exp(psi[,k,t])
        psi.tilde[,k,t] = exp.psi.k.t / sum(exp.psi.k.t)
        
      #else sample using Polya Gamma
      } else { 
        
        psi.PG.output = update.psi.k.t.polya.gamma(psi[,k,t], psi.prior.mean, psi.prior.var, 
                                                   word.counts[,k,t], word.count.totals[k,t], 
                                                   update.direction, num.updates)
        
        psi[,k,t] = psi.PG.output$psi.k.t
        psi.tilde[,k,t] = psi.PG.output$psi.tilde.k.t
        
      }#else
      
    }#for t
    
  }#for k
  
  out = list(psi = psi, psi.tilde = psi.tilde)
  
  return(out)
  
}#update.psi.polya.gamma



#############################################################################
# MCMC setup -------------------------------------------------------------- #
#############################################################################

# num.senses = 2
# num.genres = 1

# #Initialise parameters AT ZERO
# phi = array(data = 0, dim = c(num.senses, num.genres, num.periods),
#             dimnames = list(Sense = 1:num.senses, Genre = 1:num.genres, Time = 1:num.periods))
# phi.tilde = aperm(aaply(exp(phi), 2, function(x) t(t(x)/colSums(x)), .drop = FALSE), c(2,1,3))

# psi = array(data = 0, dim = c(num.words, num.senses, num.periods),
#             dimnames = list(Word = 1:num.words, Sense = 1:num.senses, Time = 1:num.periods))
# psi.tilde = aperm(aaply(exp(psi), 3, function(x) t(t(x)/colSums(x))), c(2,3,1))


#Initialise parameters AT RANDOM
#Get the counts of snippets in each time period and genre
snippet.counts = table(factor(snippets$genre, levels = 1:num.genres),
                       factor(snippets$Time, levels = 1:num.periods),
                       dnn = c("Genre", "Time"))

#Initialise z randomly
random.seed = 500
set.seed(random.seed)
z = sample(1:num.senses, num.snippets, TRUE)
# z = as.numeric(factor(snippets.info$sense.id))

#Initialise phi based on the initial z
sense.counts = table(factor(z, levels = 1:num.senses), factor(snippets$genre, levels = 1:num.genres), 
                     factor(snippets$Time, levels = 1:num.periods), dnn = c("Sense", "Genre", "Time"))

phi.tilde = aperm(sapply(1:num.senses, function(k) {(sense.counts[k,,] + 0.01) / (snippet.counts + 0.01*num.senses)}, simplify = "array"), c(3,1,2))
dimnames(phi.tilde) = list(Sense = 1:num.senses, Genre = 1:num.genres, Time = 1:num.periods)

phi = sapply(1:num.periods, function(t) {t(log(t(phi.tilde[,,t]) / phi.tilde[num.senses,,t]))}, simplify = "array")
dimnames(phi) = dimnames(phi.tilde)

#Adjust phi for identifiability
phi = aperm(sapply(1:num.genres, function(g) {t(t(phi[,g,]) - colMeans(phi[,g,]))}, simplify = "array"), c(1,3,2))
dimnames(phi) = dimnames(phi.tilde)


#Initialise psi based on the initial z
snippets.expanded = gather(cbind(snippets, sense = z), key = position, value = word, 1:snippet.length)

word.counts = table(factor(snippets.expanded$word, levels = 1:num.words),
                    factor(snippets.expanded$sense, levels = 1:num.senses),
                    factor(snippets.expanded$Time, levels = 1:num.periods),
                    dnn = c("Word", "Sense", "Time"))

psi.tilde = sapply(1:num.periods, function(t) {sapply(1:num.senses, function(k)
  {(word.counts[,k,t]+0.01)/(sum(word.counts[,k,t])+0.01*num.words)}, simplify = "aray" )}, simplify = "array" )
dimnames(psi.tilde) = list(Word = 1:num.words, Sense = 1:num.senses, Time = 1:num.periods)

psi = sapply(1:num.periods, function(t) {t(log(t(psi.tilde[,,t]) / psi.tilde[num.words,,t]))}, simplify = "array")
dimnames(psi) = dimnames(psi.tilde)

#Adjust psi for identifiability
psi = sapply(1:num.periods, function(t) {t(t(psi[,,t]) - colMeans(psi[,,t]))}, simplify = "array")
dimnames(psi) = dimnames(psi.tilde)


#Set variance for psi
kappa.psi = 1/10


#Set initial variance for phi
kappa.phi = 1/4

#Set parameters for resampling kappa.phi
resample.kappa.phi.every = 50 #resample every this many iterations
resample.kappa.phi.after = 150 #start resampling from this iteration


#Prior hyperparameters for phi precision parameter (which has inv Gamma distribution)
kappa.phi.shape.prior = 7
kappa.phi.rate.prior  = 3

#Posterior shape hyperparameter for kappa.phi - this remains fixed throughout
kappa.phi.shape = kappa.phi.shape.prior + 0.5 * num.senses * num.periods * num.genres


#Make a list of all Snippet IDs in each time period and genre
SnippetIDs = setNames(replicate(num.periods, list( setNames(vector("list", length = num.genres), 
                                                            paste("Genre", 1:num.genres, sep = "")) )), 
                      paste("Time", 1:num.periods, sep = "") )
for (t in 1:num.periods) {
  for (g in 1:num.genres) {
    SnippetIDs[[t]][[g]] = snippets[with(snippets, Time == t & genre == g), "SnippetID"]
  }#for
}#for


#Get initial probabilities for all snippets belonging to each sense
sense.probs = array(dim = c(num.senses, num.snippets),
                    dimnames = list(Sense = 1:num.senses, SnippetID = snippets$SnippetID))
for(t in 1:num.periods) {
  for(g in 1:num.genres) {
    sense.probs[,SnippetIDs[[t]][[g]]] = apply(snippets[SnippetIDs[[t]][[g]], 1:snippet.length], 1, get.sense.prob,
                                               phi.tilde[,g,t], psi.tilde[,,t])
  }#for
}#for


#Specify number of iterations in the Polya Gamma strategy
phi.PG.num.iterations = 1
psi.PG.num.iterations = 1


#Specify number of MCMC iterations
num.iterations = 10000

#Specify number of times to run the above MCMC iterations
num.runs = 1


#We will alternately go forward and backward over, time, senses and words for each successive iteration
time.direction = 1:num.periods
sense.direction = 1:num.senses
word.direction = 1:num.words


#Set up arrays to hold simulated values

z.sim = array(dim = c(num.iterations, num.snippets), 
              dimnames = list(Iteration = 1:num.iterations, Snippet = 1:num.snippets))

phi.tilde.sim = array(dim = c(num.iterations, num.senses, num.genres, num.periods),
                      dimnames = list(Iteration = 1:num.iterations, Sense = 1:num.senses, 
                                      Genre = 1:num.genres, Time = 1:num.periods))

psi.tilde.sim = array(dim = c(num.iterations, num.words, num.senses, num.periods),
                      dimnames = list(Iteration = 1:num.iterations, 
                                      Word = 1:num.words, Sense = 1:num.senses, Time = 1:num.periods))

kappa.phi.sim = numeric((num.iterations - resample.kappa.phi.after) / resample.kappa.phi.every + 1)
kappa.phi.rate.sim  = numeric((num.iterations - resample.kappa.phi.after) / resample.kappa.phi.every + 1)

sense.probs.sim = array(dim = c(num.iterations, num.senses, num.snippets),
                        dimnames = list(Iteration = 1:num.iterations, 
                                        Sense  = 1:num.senses, SnippetID = snippets$SnippetID))


### ------------------------------ Run MCMC ------------------------------ ###

progress.bar = txtProgressBar(min = 1 , max = num.iterations, style = 3) #Show progress

save(snippets, snippets.info, words.used, num.words, num.snippets, snippet.length, snippet.lengths, num.periods, num.genres, num.senses, file = "snippets.RData")
save(z, file = "initial.z.RData")
save(num.iterations, kappa.phi.shape.prior, kappa.phi.rate.prior, kappa.psi, random.seed, file = "other.parameters.RData")

for (b in 1:num.runs) {
  
  Start.Time = Sys.time() #Save start time
  for (i in 1:num.iterations) {
    
    # --- z updates --- #
    
    #Sample new z
    z = apply(sense.probs, 2, sample, x = num.senses, size = 1, replace = FALSE)
    
    #Get the counts of snippets under these sense assignments for each time period and genre
    sense.counts = table(factor(z, levels = 1:num.senses), factor(snippets$genre, levels = 1:num.genres), 
                         factor(snippets$Time, levels = 1:num.periods), dnn = c("Sense", "Genre", "Time"))
    
    #Get the counts of words under these sense assignments
    snippets.expanded = gather(cbind(snippets, sense = z), key = position, value = word, 1:snippet.length)
    word.counts = table(factor(snippets.expanded$word, levels = 1:num.words), 
                        factor(snippets.expanded$sense, levels = 1:num.senses), 
                        factor(snippets.expanded$Time, levels = 1:num.periods), 
                        dnn = c("Word", "Sense", "Time"))
    
    #Get the total number of words under each sense and time period
    word.count.totals = apply(word.counts, 2:3, sum)
    
    
    # --- psi updates --- #
    
    psi.PG.output = update.psi.polya.gamma(psi, word.counts, word.count.totals, word.direction, psi.PG.num.iterations)
    psi[,,] = psi.PG.output$psi
    psi.tilde[,,] = psi.PG.output$psi.tilde
    
    
    # --- phi updates --- #

    phi.PG.output = update.phi.polya.gamma(phi, sense.counts, snippet.counts, sense.direction, phi.PG.num.iterations)
    phi[,,] = phi.PG.output$phi
    phi.tilde[,,] = phi.PG.output$phi.tilde
    
    
    #Get probabilities for all snippets belonging to each sense
    for(t in 1:num.periods) {
      for(g in 1:num.genres) {
        sense.probs[,SnippetIDs[[t]][[g]]] = apply(snippets[SnippetIDs[[t]][[g]], 1:snippet.length], 1, get.sense.prob,
                                                   phi.tilde[,g,t], psi.tilde[,,t])
      }#for
    }#for
    
    
    #Store values
    z.sim[i,] = z
    # phi.sim[i,,,] = phi
    # psi.sim[i,,,] = psi
    phi.tilde.sim[i,,,] = phi.tilde
    psi.tilde.sim[i,,,] = psi.tilde
    sense.probs.sim[i,,] = sense.probs
    
    
    # --- kappa.phi update --- #
    
    if( (i >= resample.kappa.phi.after) & ((i %% resample.kappa.phi.every) == 0) ) { #Check whether we need to resample
      #Update rate hyperparameter
      kappa.phi.rate = update.kappa.phi.rate(phi)
      kappa.phi.rate.sim[(i - resample.kappa.phi.after) / resample.kappa.phi.every + 1] = kappa.phi.rate
      
      #Update kappa.phi
      kappa.phi = update.kappa.phi(kappa.phi.shape, kappa.phi.rate)
      kappa.phi.sim[(i - resample.kappa.phi.after) / resample.kappa.phi.every + 1] = kappa.phi
    }#if
    
    
    #Reverse word direction for next iteration
    word.direction = rev(word.direction)
    
    #Reverse sense direction for next iteration
    sense.direction = rev(sense.direction)
    
    #Reverse time direction for next iteration
    time.direction = rev(time.direction)
    
    
    #Show progress
    setTxtProgressBar(progress.bar, i)
    
  }#for
  
  close(progress.bar)
  End.Time = Sys.time() #Save finish time
  
  #Duration of algorithm
  Run.Time = End.Time - Start.Time
  print(Run.Time)
  
  #Write results to file
  filename.suffix = paste((b-1)*num.iterations+1, b*num.iterations, sep = "-")

  save(psi.tilde.sim, file = paste("psi.tilde.sim", filename.suffix, "RData", sep = "."))
  save(phi.tilde.sim, file = paste("phi.tilde.sim", filename.suffix, "RData", sep = "."))
  save(z.sim, file = paste("z.sim", filename.suffix, "RData", sep = "."))
  save(kappa.phi.sim, file = paste("kappa.phi.sim", filename.suffix, "RData", sep = "."))
  save(kappa.phi.rate.sim, file = paste("kappa.phi.rate.sim", filename.suffix, "RData", sep = "."))
  save(sense.probs.sim, file = paste("sense.probs.sim", filename.suffix, "RData", sep = "."))
  save(Start.Time, End.Time, Run.Time, file = paste("run.time", filename.suffix, "RData", sep = "."))
  
}#for b




#############################################################################
# MCMC results ------------------------------------------------------------ #
#############################################################################

#Likelihood
log.lik.sim = colSums(log(apply(sense.probs.sim, 1, colSums)))
plot(log.lik.sim, type = "l")
mean(log.lik.sim)

burn.in = 8000
plot(log.lik.sim[-(1:burn.in)], type = "l")
mean(log.lik.sim[-(1:burn.in)])


#Trace plots - phi
Time = 3
Genre = 2
plot(as.mcmc(phi.tilde.sim[,,Genre,Time]))
plot(as.mcmc(phi.tilde.sim[-(1:burn.in),,Genre,Time]))


#Trace plots - psi
Time = 1
Sense = 1
Words = 1:3
plot(as.mcmc(psi.tilde.sim[,Words,Sense,Time]))
plot(as.mcmc(psi.tilde.sim[-(1:burn.in),Words,Sense,Time]))


#Trace plots - kappa.phi
plot(as.mcmc(kappa.phi.sim))
plot(as.mcmc(kappa.phi.rate.sim))



#############################################################################
# Load results ------------------------------------------------------------ #
#############################################################################

load("snippets.RData")
load("other.parameters.RData")
load("initial.z.RData")

b = 1
filename.suffix = paste((b-1)*num.iterations+1, b*num.iterations, sep = "-")

load(paste("psi.tilde.sim", filename.suffix, "RData", sep = "."))
load(paste("phi.tilde.sim", filename.suffix, "RData", sep = "."))
load(paste("z.sim", filename.suffix, "RData", sep = "."))
load(paste("kappa.phi.sim", filename.suffix, "RData", sep = "."))
load(paste("kappa.phi.rate.sim", filename.suffix, "RData", sep = "."))
load(paste("sense.probs.sim", filename.suffix, "RData", sep = "."))
load(paste("run.time", filename.suffix, "RData", sep = "."))
